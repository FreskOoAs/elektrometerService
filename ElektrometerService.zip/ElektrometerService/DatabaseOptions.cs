﻿namespace ElektrometerService
{
    public class DatabaseOptions
    {
        public string ConnectionString { get; set; } = string.Empty;
    }
}
