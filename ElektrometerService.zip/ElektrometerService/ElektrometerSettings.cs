﻿namespace ElektrometerService
{
    public class ElectrometerSettings
    {
        public string BaseUrl { get; set; } = string.Empty;
        public string LoginUrl { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string SysSn { get; set; } = string.Empty;
        public string StationId { get; set; } = string.Empty;
        public string CentralId { get; set; } = "123456";
        public int FetchIntervalMinutes { get; set; } = 10; //default

    }

    public class OutputSettings
    {
        public string JsonFilePath { get; set; } = string.Empty;
    }

    public class AuthResponse
    {
        public int Code { get; set; }
        public string Msg { get; set; } = string.Empty;
        public AuthData Data { get; set; } = new();
    }

    public class AuthData
    {
        public string Token { get; set; } = string.Empty;
        public string RefreshToken { get; set; } = string.Empty;
    }
}
