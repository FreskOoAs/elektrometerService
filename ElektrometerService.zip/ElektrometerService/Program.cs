using ElektrometerService;

// Create and configure the host
IHostBuilder hostBuilder = Host.CreateDefaultBuilder(args)
    .ConfigureAppConfiguration((hostingContext, config) =>
    {
        // Load appsettings.json
        config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
    })
    .ConfigureServices((hostContext, services) =>
    {
        // Bind configuration sections to strongly-typed settings
        services.Configure<ElectrometerSettings>(hostContext.Configuration.GetSection("ElectrometerSettings"));
        services.Configure<OutputSettings>(hostContext.Configuration.GetSection("OutputSettings"));
        services.Configure<DatabaseOptions>(hostContext.Configuration.GetSection("Database"));

        // Register the background worker
        services.AddHostedService<Worker>();
    });

// Build and run the host
hostBuilder.Build().Run();
